<?php
if(empty($_POST)){
	header( "Location: index.html");
}else if($_POST["username"] == "admin@123" && $_POST["password"] == "admin"){
	echo "<script type='text/javascript'>alert('Welcome Admin.');</script>";
}else{
	header("Location: index.html");
}

?>
<!DOCTYPE html>

<html>

<!--
	Student ID: C0701202
	Student Name: Danilo Silveira
	Class: S-MAD-2017 Evening
	Date Created: 06-06-2017
	Copyright &copy; 2017
-->

<head>
   <title>Student Details form</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
   <meta http-equiv="Content-Language" content="en-us" />
   <link rel="stylesheet" type="text/css" href="designer.css">
</head>

<body>
<div id="main" >
	<header>
	<h1 style="text-align: center;">Student Details form</h1>
</header>

<article>
	<form action="displayTable.php" method="post" target="_self">
		<input class="fields" type="text" name="firstName" id="firstName" placeholder="First Name" required>
		<input class="fields" type="text" name="lastName" id="lastName" placeholder="Last Name" required></br>
		<input class="fieldsRadio" type="radio" name="gender" value="Male" checked="">Male</br>
		<input class="fieldsRadio" type="radio" name="gender" value="Female">Female</br>
		<input class="fields" type="text" name="email" id="email" placeholder="Your Email" required>
		<input class="fields" type="number" name="contact" id="contact" placeholder="Contact" required>
		 <select class="fields" id="city" name="city" required>
                              <option value="0">[-Select City-]</option>
                              <option value="Toronto">Toronto</option>
                              <option value="Montreal">Montreal</option>
                              <option value="Quebec">Quebec</option>
                              <option value="Ottawa">Ottawa</option>
         </select>
         <select class="fields" id="hobbey" name="hobbey" required>
                              <option value="0">[-Select Hobbey-]</option>
                              <option value="Soccer">Soccer</option>
                              <option value="Book">Book</option>
                              <option value="Cinema">Cinema</option>
                              <option value="Travel">Travel</option>
         </select>
         <textarea name="description" id="description" placeholder="Description" rows="5" required></textarea>
         <button class="btn">Cancelar</button> 
         <button type="submit" class="btn" style="margin-left: 1%;">Submit</button></br>
	</form>
</article>
</div>

<!-- 
	Implement your ideas and knowledge here
	Wish you all the best
-->

</body>
</html>

<!--

	Note:
		All tags and attributes must be lower-case characters.
		All attributes MUST contain a value and that value must be quoted.
		Use proper nesting - the last tag opened must be the first tag closed.
		Use http://www.lipsum.com/ to generate dummy text

-->