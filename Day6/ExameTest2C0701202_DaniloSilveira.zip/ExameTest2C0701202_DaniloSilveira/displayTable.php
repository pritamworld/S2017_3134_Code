<?php
if(empty($_POST)){
	header( "Location: index.html");
}

?>
<!DOCTYPE html>

<html>

<!--
	Student ID: C0701202
	Student Name: Danilo Silveira
	Class: S-MAD-2017 Evening
	Date Created: 06-06-2017
	Copyright &copy; 2017
-->

<head>
   <title>Student Details Table</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
   <meta http-equiv="Content-Language" content="en-us" />
   <link rel="stylesheet" type="text/css" href="designer.css">
</head>

<body>
<div id="tableDiv">
	<header>
	<h1 style="text-align: center;">Student Details Table</h1>
</header>

<article>
<table id="mainTable">
    <thead>
      <tr>
    <th>First Name</th>
    <th>Last Name</th> 
    <th>Gender</th>
    <th>Email</th> 
    <th>Contact</th>
    <th>City</th>
    <th>Hobbey</th>
    <th>Description</th>

  </tr>
  <tr>
  	<td><?php echo $_POST["firstName"]; ?></td>
  	<td><?php echo $_POST["lastName"]; ?></td>
  	<td><?php echo $_POST["gender"]; ?></td>
  	<td><?php echo $_POST["email"]; ?></td>
  	<td><?php echo $_POST["contact"]; ?></td>
  	<td><?php echo $_POST["city"]; ?></td>
  	<td><?php echo $_POST["hobbey"]; ?></td>
  	<td><?php echo $_POST["description"]; ?></td>
  </tr>
    </thead>
	</table>
</article>
</div>

<!-- 
	Implement your ideas and knowledge here
	Wish you all the best
-->

</body>
</html>