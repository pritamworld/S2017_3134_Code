<?php
 $json = '[
	{
		"name":"Alfreds Futterkiste"
	},
	{
		"name":"Ana Trujillo Emparedados y helados"
	},
	{
	 	"name":"Antonio Moreno Taqueria"
	},
	{
		"name":"Around the Horn"
	},
	{
		"name":"Berglunds snabbkop"
	},
	{
		"name":"Blauer See Delikatessen"
	},
	{
		"name":"Blondel pere et fils"
	},
	{
		"name":"Bolido Comidas preparadas"
	},
	{
		"name":"Bon app"
	},
	{
		"name":"Bottom Dollar Marketse"
	}
]';


$arrayNames = json_decode($json);
?>

<!DOCTYPE html>

<html>

<!--
	Student ID: C0701202
	Student Name: Danilo Silveira
	Class: S-MAD-2017 Evening
	Date Created: 06-06-2017
	Copyright &copy; 2017
-->

<head>
   <title>Json Display</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
   <meta http-equiv="Content-Language" content="en-us" />
   <link rel="stylesheet" type="text/css" href="designer.css">
</head>

<body>
<h2>Names</h2>
  <ol>
  <?php 
  	foreach ($arrayNames as $key => $value) {
  			echo "<li>".$value->name."</li>";
  			
  		}	
  ?>
    
  </ol>

</body>
</html>